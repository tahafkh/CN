#define NO_ROUTE -1

// Commands
#define TOPOLOGY "topology"
#define LSRP "lsrp"
#define DVRP "dvrp"
#define SHOW "show"
#define MODIFY "modify"
#define REMOVE "remove"
